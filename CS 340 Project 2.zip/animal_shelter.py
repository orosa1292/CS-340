#Oscar Rosa
#SNHU CS-340
#August 16, 2024
from pymongo import MongoClient
from bson.objectid import ObjectId
import urllib.parse 


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
     #property variables
    records_updated = 0 #keep a record of the records updated in an operation; CYA
    records_matched = 0 #keep a record of the records macthed in an operation; CYA
    records_deleted = 0 #keep a record of the records deleted in an operation; CYA


    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30288
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def createRecord(self, data):
        if data:
            insertValid = self.database.animals.insert_one(data)
            #check the status of the inserted value 
            return True if insertValid.acknowledged else False

        else:
            raise Exception("No document to save. Data is empty.")
            
# Create method to implement the R in CRUD.
    def getRecordId(self, postId):
        data = self.database.find_one({'_id': ObjectId(postId)})
                                  
        return data
    
    #Get records with criteria
    #All records are returned if criteria is None
    #Default is None
    #Example: ({""name": "Rex", 'age_upon_outcome': '2 months'})
    #do not return the _id
    def getRecordCriteria(self, criteria):
        if criteria:
            data = self.database.animals.find(criteria, {'_id' : 0})
                                 
        else:
            data = self.database.animals.find({}, {'_id' : 0})
                                  
        return data
    
    #Update record
    def updateRecord(self, query, newValue):
        if not query:
            raise Exception("No search criteria is present.")
            
        elif not newValue:
            raise Exception("No update value is present.")
            
        else:
            updateValid = self.database.animals.update_many(query, {"$set": newValue})
            self.records_updated = updateValid.modified_count
            self.records_matched = updateValid.matched_count

            return True if updateValid.modified_count > 0 else False
        
    #Delete record
    def deleteRecord(self, query):
        if not query:
            raise Exception("No search criteria is present.")
        
        else:
            deleteValid = self.database.animals.delete_many(query)
            self.records_deleted = deleteValid.deleted_count

            return True if deleteValid.deleted_count > 0 else False 
    